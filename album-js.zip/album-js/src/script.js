//Array (Arreglo) para las imagenes, aquí van a poner las imagenes//
//de cada uno (ES INDIVIDUAL)//

const imagenes = ["https://i.pinimg.com/736x/51/77/25/517725f7edbc59b6a96e6411958e2a2d.jpg",
                  
 "https://i.pinimg.com/736x/ba/f6/4d/baf64de62a43d37747284587001efe0b.jpg",
     
"https://i.pinimg.com/1200x/fd/10/b3/fd10b3c0e724339932d371ad2b975e7e.jpg",
                  
"https://i.pinimg.com/736x/07/1d/e1/071de1158dc5198bf730def10d6f0363.jpg",
                  
"https://i.pinimg.com/1200x/f8/b8/00/f8b8008c9ed7f9e26f540150bade781b.jpg",
                 
 ]

//Selección de elementos//

const boton = document.getElementaryById("btn-cambiar");

const imagenCard = document.getElementaryById("card-img");

const textoCard = document.getElementaryById("card-text");

//contador de las imagenes//

let indice = 0;

//Evento del click//

boton.addEventListener("click", ()=> 
 {
  //lo siguiente es para que avance la foto//
  indice++;
  
  //el siguiente if es para cuando llegue al final se regrese al inicio//
  
  if(indice >= imagenes.length){
    indice = 0;

   // Cambiar imagen y texto//
  imagenCard.src = imagenes[indice];
  textoCard.textContent = 'Mostrando imagen ${indice + 1} de ${imagenes.length}';
});