# JS- colors change

A Pen created on CodePen.

Original URL: [https://codepen.io/KARLA-ISABEL-SANTAMARIATORRES/pen/azvXbRa](https://codepen.io/KARLA-ISABEL-SANTAMARIATORRES/pen/azvXbRa).

